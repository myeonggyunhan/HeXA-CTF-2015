# r = ?, inv = ?  gcd(q,r) = 1,  q > sum(sack) 
def knapsack():
    knapsack = [1]
    tmp = 0
    for i in range(100):
        for j in range(i):
            tmp += knapsack[j]
        tmp += inv
        knapsack.append(tmp)
    return knapsack


def modulus(sack,q,r):
    for i in range(len(sack)):
        sack[i] = (sack[i]*r)%q
    return sack
    

def mixmix(supsack):
    tmp = 0
    for i in range(len(supsack)):
        tmp += supsack[i]
    tmp += r
    for i in range(100):
        if tmp%r == 0:
            tmp += 1
        else:
            sack = modulus(supsack,tmp,r)       
    print tmp
    return sack


def ciphergen():
    f = open("a.txt","r")
    ptxt = f.read()
    ctxt = 0
    supsack = knapsack()
    sack = mixmix(supsack)
    for i in range(len(ptxt)):
        if ptxt[i]== '1':
            ctxt += sack[i]
    return ctxt, sack


ciphertxt ,sack= ciphergen()

f = open("pubkey.txt","w")

for i in range(len(sack)):
    f.write(str(sack[i])+" ")

print ciphertxt
